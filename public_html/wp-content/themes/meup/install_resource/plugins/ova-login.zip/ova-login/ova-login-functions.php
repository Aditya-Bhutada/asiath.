<?php defined( 'ABSPATH' ) || exit;

// Send mail to User
function ova_register_mailto_user ( $mail_to ) {


	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";

	// Body
	if( function_exists( 'EL' ) ){

		$body = EL()->options->mail->get( 'mail_new_acocunt_content', esc_html__( 'You registered user [el_link_profile] successfully at [el_link_home_page]', 'ova-login' ) );

	}else{

		$body = esc_html__( 'You registered user [el_link_profile] successfully at [el_link_home_page]', 'ova-login' );

	}

	$body = str_replace( '[el_link_home_page]', get_site_url(), $body);
	$body = str_replace( '[el_link_profile]', '<a href="'.esc_url( get_author_posts_url( get_user_by('email', $mail_to)->ID ) ).'">'.esc_html( get_author_posts_url( get_user_by('email', $mail_to)->ID ) ).'</a>', $body);
	

	// Subject
	$subject = esc_html__( 'Register user successlly', 'ova-login' );
	

	add_filter( 'wp_mail_from', 'wp_mail_from_new_account' );
	add_filter( 'wp_mail_from_name', 'wp_mail_from_name_new_account_user' );

	if( wp_mail( $mail_to, $subject, $body, $headers ) ){
		$result = true;
	}else{
		$result = false;
	}

	remove_filter( 'wp_mail_from', 'wp_mail_from_new_account' );
	remove_filter( 'wp_mail_from_name','wp_mail_from_name_new_account_user' );

	return $result;

}



// Send mail to Admin
function ova_register_mailto_admin ( $type_user, $mail_to ) {


	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";

	// Body
	if( function_exists( 'EL' ) ){

		$body = EL()->options->mail->get( 'mail_new_acocunt_content', esc_html__( 'You registered user [el_link_profile] successfully at [el_link_home_page]', 'ova-login' ) );

	}else{

		$body = esc_html__( 'You registered user [el_link_profile] successfully at [el_link_home_page]', 'ova-login' );

	}

	$body = str_replace( '[el_link_home_page]', get_site_url(), $body);
	$body = str_replace( '[el_link_profile]', '<a href="'.esc_url( get_author_posts_url( get_user_by('email', $mail_to)->ID ) ).'">'.esc_html( get_author_posts_url( get_user_by('email', $mail_to)->ID ) ).'</a>', $body);
	

	// Subject
	if ($type_user == 'vendor') {
		$subject = esc_html__( 'New Vendor', 'ova-login' );
	}else{
		$subject = esc_html__( 'New User', 'ova-login' );
	}

	// Mail To
	$mails = wp_mail_from_new_account();

	$mail_new_event_recipient = function_exists( 'EL' ) ? EL()->options->mail->get('mail_new_event_recipient') : '';

	if( $mail_new_event_recipient ){
		$mails = $mails.','.$mail_new_event_recipient;
	}
	
	add_filter( 'wp_mail_from', 'wp_mail_from_new_account' );
	if ($type_user == 'vendor') {
		add_filter( 'wp_mail_from_name', 'wp_mail_from_name_new_account_type_vendor' );
	}else{
		add_filter( 'wp_mail_from_name', 'wp_mail_from_name_new_account_type_user' );	
	}
	

	if( wp_mail( $mails, $subject, $body, $headers ) ){
		$result = true;
	}else{
		$result = false;
	}


	remove_filter( 'wp_mail_from', 'wp_mail_from_new_account' );
	if ($type_user == 'vendor') {
		remove_filter( 'wp_mail_from_name', 'wp_mail_from_name_new_account_type_vendor' );
	} else {
		remove_filter( 'wp_mail_from_name','wp_mail_from_name_new_account_type_user' );
	}

	return $result;
}

function wp_mail_from_name_new_account_type_vendor(){
	return esc_html__( 'New Vendor', 'ova-login' );
}

function wp_mail_from_name_new_account_type_user(){
	return esc_html__( 'New User', 'ova-login' );	
}


function wp_mail_from_new_account(){

	if( function_exists( 'EL' ) && EL()->options->mail->get('mail_new_acocunt_from_email') ){

		return EL()->options->mail->get('mail_new_acocunt_from_email');

	}else{

		return get_option('admin_email');	

	}

}


function wp_mail_from_name_new_account_user(){

	return esc_html__("Register user Successfully", 'ova-login');	
	
}

