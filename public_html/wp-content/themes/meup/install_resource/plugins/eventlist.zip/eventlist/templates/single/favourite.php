<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>

<span class="event-single-favourite item-meta">
	<i class="far fa-heart"></i>
	120
</span>