<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>

<a href="javascript:void(0)" class="event-single-share item-meta">
	<i class="fas fa-share-alt"></i>
</a>