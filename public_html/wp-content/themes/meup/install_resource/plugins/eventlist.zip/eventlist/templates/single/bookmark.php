<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>

<a href="javascript:void(0)" class="event-single-bookmark item-meta">
	<i class="far fa-bookmark"></i>
	<?php esc_html_e("Bookmark", "eventlist") ?>
</a>