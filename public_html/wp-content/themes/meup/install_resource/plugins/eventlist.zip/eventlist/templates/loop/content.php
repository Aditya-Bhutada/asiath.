<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>

<div class="event_content">
	<?php the_content(); ?>
</div>