<?php

if ( !defined( 'ABSPATH' ) ) {
	exit();
}

abstract class EL_Abstract_Event{

	function __construct( $params = null ) {
        
    }

   
    
}