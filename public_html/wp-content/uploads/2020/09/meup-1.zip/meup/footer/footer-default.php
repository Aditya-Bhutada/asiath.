<footer class="footer">
	<div class="container">
		<?php esc_html_e( 'Design and Develop by Ovatheme', 'meup' ); ?>
	</div>
</footer>