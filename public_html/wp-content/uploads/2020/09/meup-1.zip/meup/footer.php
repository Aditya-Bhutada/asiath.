			
			<div class="ovafooter">
				<?php wp_reset_postdata(); ?>
				<?php	echo apply_filters( 'meup_render_footer', '' ); ?>
			</div>
			
		</div> <!-- Ova Wrapper -->	
		<?php wp_footer(); ?>
	</body><!-- /body -->
</html>